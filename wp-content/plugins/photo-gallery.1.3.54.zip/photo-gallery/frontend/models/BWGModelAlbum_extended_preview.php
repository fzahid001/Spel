<?php
class BWGModelAlbum_extended_preview {
}