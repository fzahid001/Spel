<?php
class BWGModelSlideshow {
}