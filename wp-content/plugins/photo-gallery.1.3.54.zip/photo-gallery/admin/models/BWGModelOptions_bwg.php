<?php

class BWGModelOptions_bwg {
}