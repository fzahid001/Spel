﻿=== SB Image Hover Effects ===
Contributors: Biplob018
Donate link: https://www.oxilab.org
Tags: awesome css3 effects, awesome image effects, CSS Animation, css effects, css3, css3 effects, effects, effects css3, responsive images, css3 powered effects, effects hover, hover, hover css effects, hover effects, mouse over top hover effects wordpress, animated image wp, 3d style effects, top image effects for wordpress, top image caption for wordpress, wordpress image hover plugin, image styles wordpress, best photo caption, best hover effects, best image caption wordpress, wordpress animation, css3 image caption, hover effect, css3 hover effects, css3 transition, animation, button, circle, css3, creative, css, effect, gallery, grid, hover, image, material, minimal, 3d, animated, animation, clean, css, css3, effects, hover, gallery, grid, hover, square, thumbnail, transition, caption, css3, hover, image, Caption Wordpress Plugin, latest css3 effects, Css Caption Plugin, pure css3 effects, awesome image effects, responsive hover effects, gallery, photogallery, photos, text effect, thumbnails, wordpress hover, ihover wordpress plugin, image hover, wp image caption, css3 transition, content hover, captions, image captions, pure css3 effects, css3 hover item, css3 effects for wordpress, 2016 top image caption
Requires at least: 4.4
Tested up to: 4.8.2
Stable tag: 6.5
Requires PHP: 5.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

SB Image Hover Effects is an impressive image hover plugin that will allow user to add 200+ hover effects, powered by pure css3 and ihover .

== Description ==

<strong>SB Image Hover Effects </strong>is a responsive plugin for <strong>Wordpress</strong> powered by pure <strong>CSS3</strong> and <strong>ihover</strong>. It is an awesome plugin with 200+ image effect with unlimited style, categories and shortcodes. Those categories contain unlimited image of each.

<blockquote>
   <strong>Awesome Image Hover Effects or Captions Hover Plugin for WordPress</strong>
   <br>
   <br>
</blockquote>

 There have <strong>no Javascript</strong> complications and no more complexities in use. Users can easily add attractive hover effects using an image & embed them in separate page post or widgets via amazing SB image hover shortcode builder. You need not know CSS coding at all for add this kind of image effect on your site. It is the fastest and easiest image hover effects plugin to set up in just a few minutes. You can easily add <strong>200+ attractive hover effects</strong> (With Pro) without any scripting at all. Having proper touch of image hover effects plugin websites can get more furnish than ever. 

<h3>Quick Links</h3>
<ul>
	<li><a href="https://www.oxilab.org/sb-image-hover-effects-demo">Demo (Features)</a></li>
	<li><a href="https://www.oxilab.org/sb-image-hover-effects-demo-general">Demo 1(General Hover Effects)</a></li>
	<li><a href="https://www.oxilab.org/sb-image-hover-effects-demo-square">Demo 2 (Square Hover Effects)</a></li>
	<li><a href="https://youtu.be/8LTmvNrcxYg">How to Use (Video)</a></li>
	<li><a href="https://www.oxilab.org/docs/sb-image-hover-effects/getting-started/installing-for-the-first-time/">How to Use (Documentation)</a></li>
	<li><a href="https://wordpress.org/support/plugin/sb-image-hover-effects/">Help and Support</a></li>
	<li><a href="https://www.oxilab.org/downloads/sb-image-hover-pro/">Upgrade to Pro</a></li>
</ul>

<strong>Touch Screen capable Image Hover Effects</strong>

SB Image Hover Effects Plugins Works properly on Each Touch Device On Android or IPhone or Others Touch Device. Our Awesome Effects can capture each Device Capable Effects.

<strong>Builtin Visual Composer Extension</strong>

Works on Visual Composer with Our Builtin Visual Composer Extension. So take a Drinks or Hot Coffee as a visual Composer Users.


<strong>Work with another Page builders</strong>

On Others page Builder you can Also welcome, We create Builtin Widgets Extension also Powerful Shortcode for most Common Page Builder such as SiteOrigin, Divi, Elementor or Others.  

Developers who use this plugin can bring their images to live with some beautiful animation and transition. In Pro version they will find unlimited color option and each Circle Effects with <strong>4 Animation</strong>. This is a special convenience for SB users that they can make their site more beautiful by adding captions of media and showcase items in their Wordpress site using shortcodes and custom post. SB Image Hover Effects is Advanced and responsive wordpress plugin. Users can find more option in SB than previously published any plugins. This is Advance version of image effect plugin ever. 

In concern of users our expert plugin developer team added a lot of tools and options in this SB Image Hover Effects plugin. With a short time users can add multiple image hover effect on their site using unlimited image. They will find unlimited color option and animation effect as well. With Circle Effects vantage users can make elements slide out, change and animate the background color of the item and then slide the elements back in. This can be made by different color that we left with pro version. 

With SB <strong>Image Hover Effect</strong> plugin users can create some simple, yet stylish hover effects for image captions. The idea of this plugin is to have a grid of figures and apply a hover effect to the items which will reveal a caption with the title, author and a link button. As we left a lot of option and created many features users can easily manipulate the style as they need to. 

SB Image Hover Effects is an Eye catching image effects with CSS3 transition. SB Hover Effects included with Image Zoom, Image Flips, Border Hover, Fading and Sliding Effects, Content Overlays and much more. For any business website it is important that it looks attractive to the visitors. Professionals can improve their business by furnishing websites with SB hover effects plugin. 

With the custom border radius elements, Pro version’s users can create circular shapes and it’ll appear more often as design elements in websites.

###IMPORTANT: If there have any trouble or get any phony on our plugin then don’t hesitate to knock us. Our effective and earnest Support team is always ready to serve you. Please check out our website’s Contract form.

Tags: awesome css3 effects, awesome image effects, CSS Animation, css effects, css3, css3 effects, effects, effects css3, responsive images, css3 powered effects, effects hover, hover, hover css effects, hover effects, mouse over top hover effects wordpress, animated image wp, 3d style effects, top image effects for wordpress, top image caption for wordpress, wordpress image hover plugin, image styles wordpress, best photo caption, best hover effects, best image caption wordpress, wordpress animation, css3 image caption, hover effect, css3 hover effects, css3 transition, animation, button, circle, css3, creative, css, effect, gallery, grid, hover, image, material, minimal, 3d, animated, animation, clean, css, css3, effects, hover, gallery, grid, hover, square, thumbnail, transition, caption, css3, hover, image, Caption Wordpress Plugin, latest css3 effects, Css Caption Plugin, pure css3 effects, awesome image effects, responsive hover effects, gallery, photogallery, photos, text effect, thumbnails, wordpress hover, ihover wordpress plugin, image hover, wp image caption, css3 transition, content hover, captions, image captions, pure css3 effects, css3 hover item, css3 effects for wordpress, 2016 top image caption


== Installation ==

<p>Installation of <strong>SB Image Hover Effects</strong> is very simple.</p> 
<blockquote>


<strong>Option 1</strong>

<li> Download the plugin sb-hover-effects.zip from Wordpress Plugin Directory.</li>
<li> Unzip file into sb-image-hover-effects folder.</li>
<li> Drop the sb-image-hover-effects plugin folder into your wp-content/plugins folder.</li>
<li> Refresh your Wordpress Administration panels, click on Plugins from the menu.</li>
<li> You will see sb image hover effects plugin under Inactive plug-in tab.</li>
<li> To tern on sb image hover effects , click  on activate.</li>

</blockquote>

<blockquote>


<strong>Option 2</strong>

<li> Download the plugin sb-hover-effects.zip from Wordpress Plugin Directory.</li>
<li> click on add new  under plugins menu.</li>
<li> Upload the available SB image Hover Effects Plugin file and click install now</li>
<li> After installed click on active to tern on.</li>

</blockquote>

== Frequently Asked Questions ==

WordPress SB Image Hover Effects Plugin

= Whether, is the Image hover Effects support basic HTML Elements? =

Yes. Basic Html has a support possibility.Such as you can add </br>,  <strong> .

= Is the SB Image Hover Effects Responsive? =

Yes, reacts and displays resizing images, videos, titles and descriptions for mobile devices and tablets.

= I bought SB Image Hover Effects Plugin, I have not received it yet. Please suggest, how can I activate it or get the Pro version? =

If You acquired the SB Image Hover Effects and have not received it, please just contact with our Support Team. Send a letter with purchase SB Image Hover Effects Order Number.

= I use free version of SB Image Hover Effects and placing Pro version arise a problem, what to do? =

- Please delete the free version until installing the Pro version.

- Download SB Image Hover Effects Pro version. If You still see the old version press Ctrl+F5 for refresh the page.

- If you can not do that, please contact with us, we will solve this little problem.

= How to enable the SB Image Hover Effects to in a post or page? =

[sb_image_oxi id="1"]
= How to enable the SB Image Hover Effects to in a page or Template? =

&lt;?php echo do_shortcode(&#039;[sb_image_oxi  id=&quot;1&quot;]&#039;); ?&gt;

== Screenshots ==

1. Image hover Template Demo
2. Visual Composer Add element.
2. Admin panel With Live Preview.
3. Popup Data Input form.


== Changelog ==
= 6.5 =
* Redesign Admin area
* Mobile bug Fixed

= 6.4 =
* Redesign Admin Panel 
* Add more than 200+ Hover Effects  

= 6.3 =
* Resolve bugs  

= 6.2 =
* Resolve bugs  

= 6.1 =
* Resolve bugs  

= 6.0 =
* Resolve Responsive   

= 5.1 =
* Video Tutorial   

= 5.0 =
* Make more easy panel 
* Add more options  

= 3.0 =
* Develop Pro Version 
* Add more options  

= 2.0 =
* Resolve responsive layout 

= 1.0 =
* Initial Release
* responsive layout



== Upgrade Notice ==

= 6.5 =
Upgrade to Resolve Touchscreen Device Capable Hover effects and Redesign Admin Panel. 
